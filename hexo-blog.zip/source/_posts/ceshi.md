---
title: 想把我唱给你听
date: 2025-08-06 10:18:34
tags:
---

歌单
<iframe frameborder="no" border="0" marginwidth="0" marginheight="0" width=330 height=450 src="//music.163.com/outchain/player?type=0&id=9066609719&auto=1&height=430"></iframe>

想把我唱给你听
<iframe src="http://music.163.com/song/media/outer/url?id=1843110965.mp3" name="想把我唱给你听" scrolling="auto" width="100%" height="100%" style="border: none #b0b0b0;"></iframe>

富士山下
<iframe src="http://music.163.com/song/media/outer/url?id=2599695445.mp3" name="富士山下" scrolling="auto" width="100%" height="100%" style="border: none #b0b0b0;"></iframe>

